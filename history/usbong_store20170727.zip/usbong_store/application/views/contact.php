<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<h2 class="header">Contact Usbong Store</h2>
	<div>
		<div class="row">
			<div class="col-sm-3">
			</div>
			<div class="col-sm-9">
				<div class="Contact">For questions, concerns, suggestions, feature requests, and/or our software development service offerings, please direct them at the following email address:<br><br>
					<span class="Contact-support-email-address">support (at) usbong (dot) ph</span><br><br>
	
					We would love to hear from you then!<br><br>
	
					Maraming salamat! <i>Daghang salamat!</i> Thank you very much!<br><br>
				</div>			
			</div>
		</div>	
	</div>	
</body>
</html>